package com.example.order.dto;

import java.util.List;

public class OrderDTO {
    private String customerId;
    private List<OrderLineDTO> orderLines;

    public OrderDTO() {}

    public OrderDTO(String customerId, List<OrderLineDTO> orderLines) {
        this.customerId = customerId;
        this.orderLines = orderLines;
    }

    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }

    public List<OrderLineDTO> getOrderLines() { return orderLines; }
    public void setOrderLines(List<OrderLineDTO> orderLines) { this.orderLines = orderLines; }
}


