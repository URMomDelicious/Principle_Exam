package com.example.order;

import com.example.order.model.Customer;
import com.example.order.model.Order;
import com.example.order.model.Product;
import com.example.order.repository.CustomerRepository;
import com.example.order.repository.OrderRepository;
import com.example.order.repository.ProductRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class DataInitializer implements CommandLineRunner {

    private final CustomerRepository customerRepository;
    private final OrderRepository orderRepository;

    public DataInitializer(CustomerRepository customerRepository, OrderRepository orderRepository) {
        this.customerRepository = customerRepository;
        this.orderRepository = orderRepository;
    }

    @Override
    public void run(String... args) throws Exception {

        // 1️⃣ สร้าง Customer ก่อน
        Customer customer = new Customer();
        customer.setName("Yasinthon");
        customer.setEmail("yasin@example.com");
        customer = customerRepository.save(customer); // ต้อง save ก่อน

        // 2️⃣ สร้าง Order ที่อ้างถึง Customer
        Order order = new Order();
        order.setCustomer(customer);  // อ้างถึง Customer ที่เพิ่ง save
        order.setOrderDate(LocalDateTime.now());
        orderRepository.save(order);
    }
}
