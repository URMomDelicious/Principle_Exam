package com.example.order.controller;

import com.example.order.dto.CustomerDTO;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    // ใช้ map จำลอง database (ในของจริงจะใช้ service + repository)
    private Map<String, CustomerDTO> customerDatabase = new HashMap<>();

    // สร้างลูกค้าใหม่
    @PostMapping
    public CustomerDTO createCustomer(@RequestBody CustomerDTO customerDTO) {
        customerDatabase.put(customerDTO.getId(), customerDTO);
        return customerDTO;
    }

    // ดึงข้อมูลลูกค้าทั้งหมด
    @GetMapping
    public List<CustomerDTO> getAllCustomers() {
        return new ArrayList<>(customerDatabase.values());
    }

    // ดึงข้อมูลลูกค้าตาม ID
    @GetMapping("/{id}")
    public CustomerDTO getCustomerById(@PathVariable String id) {
        return customerDatabase.get(id);
    }

    // แก้ไขข้อมูลลูกค้า
    @PutMapping("/{id}")
    public CustomerDTO updateCustomer(@PathVariable String id, @RequestBody CustomerDTO updatedCustomer) {
        customerDatabase.put(id, updatedCustomer);
        return updatedCustomer;
    }

    // ลบลูกค้า
    @DeleteMapping("/{id}")
    public String deleteCustomer(@PathVariable String id) {
        customerDatabase.remove(id);
        return "Customer with ID " + id + " deleted.";
    }
}
