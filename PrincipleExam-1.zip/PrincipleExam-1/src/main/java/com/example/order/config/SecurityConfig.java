package com.example.order.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            // 1. ปิด CSRF (จำเป็นสำหรับ Postman)
            .csrf(csrf -> csrf.disable()) 

            // 2. กำหนดสิทธิ์
            .authorizeHttpRequests(auth -> auth
                // อนุญาต H2 Console
                .requestMatchers("/h2-console/**").permitAll() 

                // อนุญาต "ทุกเมธอด" (GET, POST, PUT, DELETE) 
                // ที่ไปยัง URL ที่ขึ้นต้นด้วย /api/
                .requestMatchers("/api/**").permitAll() 

                // URL อื่นๆ ที่เหลือทั้งหมด ต้อง Login
                .anyRequest().authenticated() 
            )

            // 3. อนุญาต H2 Console
            .headers(headers -> headers
                .frameOptions(frameOptions -> frameOptions.sameOrigin())
            );

        return http.build();
    }
}