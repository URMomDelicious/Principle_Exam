package com.example.order.service;

import com.example.order.dto.OrderDTO;
import com.example.order.model.*;
import com.example.order.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class OrderService {

    private final OrderRepository orderRepository;
    private final CustomerRepository customerRepository;
    private final ProductRepository productRepository;

    public OrderService(OrderRepository orderRepository,
                        CustomerRepository customerRepository,
                        ProductRepository productRepository) {
        this.orderRepository = orderRepository;
        this.customerRepository = customerRepository;
        this.productRepository = productRepository;
    }

    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    public Order getOrderById(String id) {
        return orderRepository.findById(id).orElseThrow(() -> new RuntimeException("Order not found"));
    }

    public Order createOrder(OrderDTO orderDTO) {
        Customer customer = customerRepository.findById(orderDTO.getCustomerId())
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        Order order = new Order();
        order.setCustomer(customer);
        order.setOrderDate(LocalDateTime.now());

        List<OrderLine> orderLines = orderDTO.getOrderLines().stream().map(ol -> {
            Product product = productRepository.findById(ol.getProductId())
                    .orElseThrow(() -> new RuntimeException("Product not found"));
            OrderLine orderLine = new OrderLine();
            orderLine.setOrder(order);
            orderLine.setProduct(product);
            orderLine.setQuantity(ol.getQuantity());
            orderLine.setTotalPrice(product.getPrice().multiply(BigDecimal.valueOf(ol.getQuantity())));
            return orderLine;
        }).collect(Collectors.toList());

        order.setOrderLines(orderLines);
        return orderRepository.save(order);
    }

    public Order updateOrder(String id, OrderDTO orderDTO) {
        Order existingOrder = getOrderById(id);

        Customer customer = customerRepository.findById(orderDTO.getCustomerId())
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        existingOrder.setCustomer(customer);

        existingOrder.getOrderLines().clear();

        List<OrderLine> updatedLines = orderDTO.getOrderLines().stream().map(ol -> {
            Product product = productRepository.findById(ol.getProductId())
                    .orElseThrow(() -> new RuntimeException("Product not found"));
            OrderLine orderLine = new OrderLine();
            orderLine.setOrder(existingOrder);
            orderLine.setProduct(product);
            orderLine.setQuantity(ol.getQuantity());
            orderLine.setTotalPrice(product.getPrice().multiply(BigDecimal.valueOf(ol.getQuantity())));
            return orderLine;
        }).collect(Collectors.toList());

        existingOrder.setOrderLines(updatedLines);
        return orderRepository.save(existingOrder);
    }

    public void deleteOrder(String id) {
        Order order = getOrderById(id);
        orderRepository.delete(order);
    }
}
